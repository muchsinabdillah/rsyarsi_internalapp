<div class="nk-header nk-header-fixed is-light">
                    <div class="container-fluid">
                        <div class="nk-header-wrap">
                            <div class="nk-menu-trigger d-xl-none ms-n1">
                                <a href="#" class="nk-nav-toggle nk-quick-nav-icon" data-target="sidebarMenu"><em class="icon ni ni-menu"></em></a>
                            </div>
                            <div class="nk-header-brand d-xl-none">
                                <a href="/" class="logo-link">
                                    <img class="logo-light logo-img" src="{{ URL::asset('images/loginJoinKilatFix.png') }}" srcset="{{ URL::asset('images/loginJoinKilatFix.png') }}" alt="logo">
                                    <img class="logo-dark logo-img" src="{{ URL::asset('images/loginJoinKilatFix.png') }}" srcset="{{ URL::asset('images/loginJoinKilatFix.png') }}" alt="logo-dark">
                                </a>
                            </div><!-- .nk-header-brand -->
                            <div class="nk-header-news d-none d-xl-block">
                                <div class="nk-news-list">
                                    <a class="nk-news-item" href="#"> 
                                            <a href="/" class="logo-link">
                                                <img class="logo-light logo-img" src="{{ URL::asset('images/loginJoinKilatFix.png') }}" srcset="{{ URL::asset('images/loginJoinKilatFix.png') }}" alt="logo">
                                                <img class="logo-dark logo-img" src="{{ URL::asset('images/loginJoinKilatFix.png') }}" srcset="{{ URL::asset('images/loginJoinKilatFix.png') }}" alt="logo-dark">
                                            </a> 
                                        <div class="nk-news-text">
                                            {{-- <p>Do you know the latest update of 2022? <span> A overview of our is now available on YouTube</span></p> --}}
                                            {{-- <em class="icon ni ni-external"></em> --}}
                                        </div>
                                    </a>
                                </div>
                            </div><!-- .nk-header-news -->
                            <div class="nk-header-tools">
                                <ul class="nk-quick-nav">
                                     
                                    <li class="dropdown user-dropdown">
                                        <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown">
                                            <div class="user-toggle">
                                                
                                                <div class="user-info d-none d-md-block">
                                                    <div class="user-status">VERIFICATION</div> 
                                                </div>
                                            </div>
                                        </a>
                                         
                                    </li><!-- .dropdown -->
                                     
                                </ul><!-- .nk-quick-nav -->
                            </div><!-- .nk-header-tools -->
                        </div><!-- .nk-header-wrap -->
                    </div><!-- .container-fliud -->
                </div>