<div class="nk-footer">
                    <div class="container-fluid">
                        <div class="nk-footer-wrap">
                            <div class="nk-footer-copyright"> &copy; 2022 RS YARSI. Template by <a href="https://rsyarsi.co.id/" target="_blank">RS YARSI.</a>
                            </div>
                            <div class="nk-footer-links">
                                <ul class="nav nav-sm">
                                     
                                     
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>