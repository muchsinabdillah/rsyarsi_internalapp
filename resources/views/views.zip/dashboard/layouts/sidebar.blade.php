<div class="nk-sidebar nk-sidebar-fixed  " data-content="sidebarMenu">
                <div class="nk-sidebar-element nk-sidebar-head">
                    <div class="nk-menu-trigger">
                        <a href="#" class="nk-nav-toggle nk-quick-nav-icon d-xl-none" data-target="sidebarMenu"><em class="icon ni ni-arrow-left"></em></a>
                        <a href="#" class="nk-nav-compact nk-quick-nav-icon d-none d-xl-inline-flex" data-target="sidebarMenu"><em class="icon ni ni-menu"></em></a>
                    </div>
                    <div class="nk-sidebar-brand"> 
                        <a href="{{ auth()->user()->level }}" class="logo-link nk-sidebar-logo">
                            <img class="logo-light logo-img" src="{{ URL::asset('img/loginJoinKilatFix.png') }}" srcset="{{ URL::asset('img/loginJoinKilatFix.png') }}" alt="logo">
                            <img class="logo-dark logo-img" src="{{ URL::asset('img/loginJoinKilatFix.png') }}" srcset="{{ URL::asset('img/loginJoinKilatFix.png') }}" alt="logo-dark">
                        </a> 
                    </div>
                </div><!-- .nk-sidebar-element -->
                <div class="nk-sidebar-element nk-sidebar-body">
                    <div class="nk-sidebar-content">
                        <div class="nk-sidebar-menu" data-simplebar>
                            <ul class="nk-menu">     
                                <li class="nk-menu-heading">
                                    <h6 class="overline-title text-primary-alt">Master Data</h6>
                                </li><!-- .nk-menu-heading --> 
                                <li class="nk-menu-item has-sub">
                                    <a href="#" class="nk-menu-link nk-menu-toggle">
                                        <span class="nk-menu-icon"><em class="icon ni ni-users"></em></span>
                                        <span class="nk-menu-text">User Manage</span>
                                    </a>
                                    <ul class="nk-menu-sub">
                                        <li class="nk-menu-item">
                                            <a href="/dashboard/userlogin" class="nk-menu-link"><span class="nk-menu-text">Entry User </span></a>
                                        </li> 
                                    </ul><!-- .nk-menu-sub -->
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item has-sub">
                                    <a href="#" class="nk-menu-link nk-menu-toggle">
                                        <span class="nk-menu-icon"><em class="icon ni ni-tile-thumb"></em></span>
                                        <span class="nk-menu-text">C.O.E</span>
                                    </a>
                                    <ul class="nk-menu-sub">
                                        <li class="nk-menu-item">
                                            <a href="/dashboard/coe" class="nk-menu-link"><span class="nk-menu-text">Entry C.O.E</span></a>
                                        </li> 
                                    </ul><!-- .nk-menu-sub -->
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item has-sub">
                                    <a href="#" class="nk-menu-link nk-menu-toggle">
                                        <span class="nk-menu-icon"><em class="icon ni ni-tile-thumb"></em></span>
                                        <span class="nk-menu-text">Fasilitas</span>
                                    </a>
                                    <ul class="nk-menu-sub">
                                        <li class="nk-menu-item">
                                            <a href="/dashboard/fasilitas" class="nk-menu-link"><span class="nk-menu-text">Entry Fasilitas</span></a>
                                        </li> 
                                    </ul><!-- .nk-menu-sub -->
                                </li><!-- .nk-menu-item -->
                                
                                <li class="nk-menu-heading">
                                    <h6 class="overline-title text-primary-alt">SYARIAH PROGRAM</h6>
                                </li><!-- .nk-menu-item -->   
                                <li class="nk-menu-item">
                                    <a href="/dashboard/patient/create" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-growth"></em></span>
                                        <span class="nk-menu-text">Entry Patient</span> 
                                    </a>
                                </li><!-- .nk-menu-item -->  
                                <li class="nk-menu-item">
                                    <a href="/dashboard/infomaternarekap" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-growth"></em></span>
                                        <span class="nk-menu-text">List Data</span> 
                                    </a>
                                </li><!-- .nk-menu-item -->  
                                <li class="nk-menu-item">
                                    <a href="/dashboard/tausiyah/list" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-growth"></em></span>
                                        <span class="nk-menu-text">Tausiyah Pagi Hari</span> 
                                    </a>
                                </li>
                                <li class="nk-menu-item">
                                    <a href="/dashboard/keluhan/list" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-growth"></em></span>
                                        <span class="nk-menu-text">Keluhan Pasien</span> 
                                    </a>
                                </li>
                                <!-- .nk-menu-item -->  
                                 
                                {{-- <li class="nk-menu-heading">
                                    <h6 class="overline-title text-primary-alt">Transaction</h6>
                                </li><!-- .nk-menu-heading -->
                                
                                <li class="nk-menu-item has-sub">
                                    <a href="#" class="nk-menu-link nk-menu-toggle">
                                        <span class="nk-menu-icon"><em class="icon ni ni-files"></em></span>
                                        <span class="nk-menu-text">Promo</span>
                                    </a>
                                    <ul class="nk-menu-sub">
                                        <li class="nk-menu-item">
                                            <a href="/dashboard/delivery"  class="nk-menu-link"><span class="nk-menu-text">Entri Promo Terbaru</span></a>
                                        </li> 
                                    </ul><!-- .nk-menu-sub -->
                                </li><!-- .nk-menu-item -->
                                   
                                <li class="nk-menu-item has-sub">
                                    <a href="#" class="nk-menu-link nk-menu-toggle">
                                        <span class="nk-menu-icon"><em class="icon ni ni-pie"></em></span>
                                        <span class="nk-menu-text">Event</span>
                                    </a>
                                    <ul class="nk-menu-sub">
                                        <li class="nk-menu-item">
                                            <a href="/dashboard/transit" class="nk-menu-link"><span class="nk-menu-text">Entri Event</span></a> 
                                        </li> 
                                    </ul><!-- .nk-menu-sub -->
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item has-sub">
                                    <a href="#" class="nk-menu-link nk-menu-toggle">
                                        <span class="nk-menu-icon"><em class="icon ni ni-puzzle"></em></span>
                                        <span class="nk-menu-text">Articles</span>
                                    </a>
                                    <ul class="nk-menu-sub">
                                        <li class="nk-menu-item">
                                            <a href="/dashboard/deliverykurir" class="nk-menu-link"><span class="nk-menu-text">Entri Articles</span></a>
                                        </li><!-- .nk-menu-item --> 
                                    </ul><!-- .nk-menu-sub -->
                                </li><!-- .nk-menu-item --> --}}
                           
                                
                                
                            </ul><!-- .nk-menu -->
                        </div><!-- .nk-sidebar-menu -->
                    </div><!-- .nk-sidebar-content -->
                </div><!-- .nk-sidebar-element -->
            </div>